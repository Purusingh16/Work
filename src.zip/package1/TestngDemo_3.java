package package1;

import org.testng.annotations.Test;

public class TestngDemo_3 {
	@Test
	  public void test1() {
		  System.out.println("from TestngDemo_3 class test1");
	  }
	  
	  @Test
	  public void test2() {
		  System.out.println("from TestngDemo_3 class test2");
	  }
}
