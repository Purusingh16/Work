package package1;

import org.testng.annotations.Test;

public class TestXmlDemo {
  @Test
  public void f() {
  }
}
